package org.edwith.webbe.securityexam.service;

import org.edwith.webbe.securityexam.service.security.UserDbService;

public interface MemberService extends UserDbService {

	// MemberServiceImpl에서 정의한 것을 받아 넘기는 인터페이스
	
}
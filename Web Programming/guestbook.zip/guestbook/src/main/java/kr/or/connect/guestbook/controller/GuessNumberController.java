package kr.or.connect.guestbook.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GuessNumberController {
	
	@GetMapping(path="/guess")
	public String guess(@RequestParam(name="number", required=false) Integer number,
						HttpSession session,
						ModelMap model) {
		String message = null;
		
		if(number == null) {		// 세션 정보가 없다면 새로 생성
			session.setAttribute("count", 0);
			session.setAttribute("randomNumber", (int)(Math.random() * 100) + 1);
			message = "1 ~ 100 사이의 숫자를 맞춰보시오.";
		}
		else {						// 세션 정보가 존재한다면 세션에서의 정보 읽기
			int count = (Integer)session.getAttribute("count");
			int randomNumber = (Integer)session.getAttribute("randomNumber");
			
			if(number < randomNumber) {			// up
				message = "Up!";
				session.setAttribute("count", ++count);
			}
			else if(number > randomNumber) {		// down
				message = "Down!";
				session.setAttribute("count", ++count);
			}
			else {
				message = "Correct! " + count + "th answer, It's " + number + ".";
				session.removeAttribute("count");
				session.removeAttribute("randomNumber");
			}
		}
		
		model.addAttribute("message", message);
		return "guess";
	}
}

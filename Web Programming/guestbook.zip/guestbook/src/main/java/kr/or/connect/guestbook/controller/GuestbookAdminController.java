package kr.or.connect.guestbook.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class GuestbookAdminController {
	
	// 로그인 페이지
	@GetMapping(path="/loginform")
	public String loginform() {
		return "loginform";
	}
	
	// 로그인 (관리자)
	@PostMapping(path="/login")
	public String login(@RequestParam(name="passwd", required=true) String password,
						HttpSession session,
						RedirectAttributes redirectAttr) {
		
		if("1234".contentEquals(password)) {	// 입력한 패스워드가 관리자용일 경우
			session.setAttribute("isAdmin", true);
		}
		else {									// 암호가 틀려 로그인에 실패할 경우
			redirectAttr.addFlashAttribute("errorMessage", "암호가 틀렸습니다.");
			return "redirect:/loginform";		// 로그인 페이지 리다이렉트
		}
		
		return "redirect:/list";				// 로그인이 될 경우 list 페이지로 간다.
	}
	
	
	// 로그아웃 (관리자)
	@GetMapping(path="/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("isAdmin");
		return "redirect:/list";
	}
}
